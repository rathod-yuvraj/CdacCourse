
public class A
{
	public static void main(String[] args)
	{
		int[] arr = {1, 2 ,3, 4};
		
		B b =new B();
		//b.show(arr);
			
		/* for (int i=0; i<arr.length; ++i)
			System.out.print(arr[i]+" ");
		System.out.println(); */
		
		b.show_vars();
		C c = new C();  String p = "Sanket"; int q = 5;
		c.demo(b,p,q);
		System.out.println("after c");
		b.show_vars();
		System.out.println("Variables: ints "+p+", "+q);
		String n1 = "Sanket", n2 ="Chalke";
		b.swap(n1,n2);
		System.out.println("After Swap: "+n1+", "+n2);
	}
}

class B
{
	int x=10,y=20;
	public void show(int[] xyz)
	{
		for (int i=0; i<xyz.length; ++i)
			System.out.print(xyz[i]+" ");
		System.out.println("Show done");
		
		xyz[2] = 98;
	}
	public void show_vars()
	{
		System.out.println("Variables: "+x+", "+y);
	}
	
	public void swap(String x, String y)
	{
		String t = x;
		x=y;
		y=t;
	}
}

class C
{
	public void demo(B s, String abc, int xyz)
	{
		s.x=80;
		s.y=90;
		
		abc = "100";
		xyz = 200;
	}
}