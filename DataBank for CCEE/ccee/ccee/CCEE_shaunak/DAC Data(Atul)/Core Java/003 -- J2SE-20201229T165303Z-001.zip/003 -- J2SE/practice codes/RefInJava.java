
public class RefInJava
{
	public static void main(String[] args)
	{
		String s1 = new String("Sanket");
		String s2 = "Chalke";
		
		String[] str1 = {"Sanket", "Chalke"};
		
		int x = 5;
		
		int[] xyz = {95,96};
		
		swap(str1, s1, s2, x, xyz);
		
		System.out.println("*****");
		System.out.println("String array: "+ str1[0]+", "+str1[1]);
		
		System.out.println("S1: "+ s1+", S2: "+s2);
		
		System.out.println("int x: "+x);
		
		System.out.println("int[] xyz: "+ xyz[0]+", "+xyz[1]);
	}
	
	static public void swap(String[] str1, String s1, String s2, int x, int[] xyz)
	{
		str1[1] = "Yeda";
		
		s1 = "YoYo";
		s2 = "Hello";
		
		x = 85;
		
		xyz[1] = 555;
	}
}