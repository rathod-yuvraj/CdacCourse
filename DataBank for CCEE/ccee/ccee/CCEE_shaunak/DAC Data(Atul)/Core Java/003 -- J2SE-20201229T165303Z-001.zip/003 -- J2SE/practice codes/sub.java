class base
{
	public final void disp ()
	{
		///  static variables are not allowed to declare inside a method.
		//int x;
		//static int y;
		System.out.println("in disp of base");
		//System.out.println("y: "+y+", x:"+x);
	}
}
public class sub extends base
{
	/// ******** Not allowed to override Final method  *****///
	/* public void disp ()
	{
		System.out.println("in disp of sub");
	} */
	
	public static void main (String argv [] )
	{
		//static int sasa = 5;
		base b = new sub() ;
		b.disp () ;
		int[] i = {1,2};
		
		try
		{
			System.exit(0);
			int x = i[5];
		}
		finally
		{
			System.out.println("in finally");
		}
	}
}
