class a
{
	static
	{
		System.out.println(" static a");
	}
}
class b extends a
{
	static
	{
		System.out.println(" static b");
	}
}
class c extends b
{
	static
	{
		System.out.println(" static c");
	}
}
public class myclass 
{
	static
	{
		System.out.println(" static  myclass");
	}
	public static void main(String args[])
	{
		new c();
		System.out.println("in main");
	}
}
