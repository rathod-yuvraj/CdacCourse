public class Trial1
{
	static double d;
	String a;
	
	public static void main(String args[])
	{
		Trial1 t1 = new Trial1();
		t1.show();
		
		if(d==0)
		{
			System.out.println("0");
		}
		else
		{
			System.out.println("garbage");
		}
	}
	
	void show()
	{
		System.out.println("a: "+a);
		System.out.println("d: "+d);
	}
}
