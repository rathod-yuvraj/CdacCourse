public class Trial
{
	int num=10;
	void change(Trial ref)
	{
		ref.num=20;
		ref=null;
		ref.num=200;
	}
	public static void main(String args[])
	{
		Trial t=new Trial();
		t.change(t);
		System.out.println(t.num);
	}
}
